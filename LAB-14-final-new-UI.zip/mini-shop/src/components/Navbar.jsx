// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectCartCount } from '../store/cartSlice.js';
import { selectWishIds } from '../store/wishlistSlice.js';

export default function Navbar() {
  // The badge updates automatically when the wishlist changes
  const count = useSelector(selectWishIds).length;

  const cartCount = useSelector(selectCartCount);

  return (
    <nav>
      <span className="brand">🛍️ Mini Shop</span>
      {/* NavLink adds the "active" class to the current page's link */}
      <NavLink to="/" end>
        Home
      </NavLink>
      <NavLink to="/wishlist">
        Wishlist <span className="badge">{count}</span>
      </NavLink>
      <NavLink to="/cart">
        Cart <span className="badge">{cartCount}</span>
      </NavLink>
    </nav>
  );
}
