// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { createSlice } from '@reduxjs/toolkit';

const wishlistSlice = createSlice({
  name: 'wishlist',
  initialState: { ids: [] },
  reducers: {
    // Add the id if it is missing, remove it if it is already there
    toggleWish(state, action) {
      const id = action.payload;
      if (state.ids.includes(id)) {
        state.ids = state.ids.filter((wishId) => wishId !== id);
      } else {
        state.ids.push(id); // safe here because Immer handles the update
      }
    },
    // Empty the whole wishlist
    clearWish(state) {
      state.ids = [];
    },
  },
});

export const { toggleWish, clearWish } = wishlistSlice.actions;

// Selector: reads the wished ids from the store
export const selectWishIds = (state) => state.wishlist.ids;

export default wishlistSlice.reducer;
