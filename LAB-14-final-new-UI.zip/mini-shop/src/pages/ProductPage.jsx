// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link, useParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard.jsx';
import { products } from '../data/products.js';
import NotFoundPage from './NotFoundPage.jsx';

export default function ProductPage() {
  const { id } = useParams();
  // URL params are strings, so convert before comparing
  const product = products.find((p) => p.id === Number(id));

  if (!product) return <NotFoundPage />;

  return (
    <section className="narrow">
      <h1>Product Details</h1>
      <ProductCard product={product} />
      <p>
        <Link to="/">← Back to Home</Link>
      </p>
    </section>
  );
}
