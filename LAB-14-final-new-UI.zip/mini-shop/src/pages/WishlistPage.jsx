// Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearWish, selectWishIds } from '../store/wishlistSlice.js';
import { products } from '../data/products.js';

export default function WishlistPage() {
  const dispatch = useDispatch();
  const wishIds = useSelector(selectWishIds);
  // Keep only the products whose id is in the wishlist
  const wished = products.filter((p) => wishIds.includes(p.id));

  return (
    <section className="wishlist">
      <h1>My Wishlist</h1>

      {wished.length === 0 ? (
        <p className="empty">Your wishlist is empty.</p>
      ) : (
        <>
          <ul className="wish-list">
            {wished.map((p) => (
              <li key={p.id}>
                <span className="wish-icon" aria-hidden="true">{p.icon}</span>
                <Link to={`/product/${p.id}`}>{p.title}</Link>
                <span className="price">Rs. {p.price.toLocaleString()}</span>
              </li>
            ))}
          </ul>
          <button type="button" className="btn" onClick={() => dispatch(clearWish())}>
            Clear wishlist
          </button>
        </>
      )}
    </section>
  );
}
