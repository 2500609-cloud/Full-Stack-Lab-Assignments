<!-- Name: YOUR NAME | Reg No: YOUR_REG_NO | CS-301L Lab 14 -->
# Mini Shop - Lab 14

Run: `npm install` then `npm run dev`, and open the URL shown in the terminal.
