const form = document.getElementById("registrationForm");
const nameInput = document.getElementById("fullName");
const emailInput = document.getElementById("email");
const programInput = document.querySelector("#program");
const semesterInput = document.querySelector("#semester");
const nameError = document.querySelector("#nameError");
const emailError = document.querySelector("#emailError");
const programError = document.querySelector("#programError");
const semesterError = document.querySelector("#semesterError");
const previewName = document.querySelector("#previewName");
const previewEmail = document.querySelector("#previewEmail");
const previewProgram = document.querySelector("#previewProgram");
const previewSemester = document.querySelector("#previewSemester");
const studentList = document.querySelector("#studentList");
const previewCard = document.querySelector("#previewCard");
const darkModeButton = document.querySelector("#darkModeButton");
nameInput.addEventListener("input", function () {
    previewName.textContent = nameInput.value;
});
emailInput.addEventListener("input", function () {
    previewEmail.textContent = emailInput.value;
});
programInput.addEventListener("input", function () {
    previewProgram.textContent = programInput.value;
});
semesterInput.addEventListener("input", function () {
    previewSemester.textContent = semesterInput.value;
});
form.addEventListener("submit", function (event) {
    event.preventDefault();
    nameError.textContent = "";
    emailError.textContent = "";
    programError.textContent = "";
    semesterError.textContent = "";
    const fullName = nameInput.value.trim();
    const email = emailInput.value.trim();
    const program = programInput.value;
    const semester = semesterInput.value;
    let isValid = true;
    if (fullName === "") {
        nameError.textContent = "Full Name is required.";
        isValid = false;
    }
    else if (fullName.length < 3) {
        nameError.textContent =
            "Name must contain at least 3 characters.";
        isValid = false;
    }
    if (email === "") {
        emailError.textContent = "Email is required.";
        isValid = false;
    }
    else if (!email.includes("@")) {
        emailError.textContent =
            "Please enter a valid email.";
        isValid = false;
    }
    if (program === "") {
        programError.textContent =
            "Please select a program.";
        isValid = false;
    }
    if (semester === "") {
        semesterError.textContent =
            "Semester is required.";
        isValid = false;
    }
    else if (semester < 1 || semester > 8) {
        semesterError.textContent =
            "Semester must be between 1 and 8.";
        isValid = false;
    }
    if (!isValid) {
        return;
    }
    const li = document.createElement("li");
    const studentName = document.createElement("strong");
    studentName.textContent = fullName;
    const studentDetails = document.createElement("p");
    studentDetails.textContent =
        "Email: " + email +
        " | Program: " + program +
        " | Semester: " + semester;
    li.appendChild(studentName);
    li.appendChild(studentDetails);
    studentList.appendChild(li);
    form.reset();
    previewName.textContent = "---";
    previewEmail.textContent = "---";
    previewProgram.textContent = "---";
    previewSemester.textContent = "---";
});
darkModeButton.addEventListener("click", function () {
    previewCard.classList.toggle("dark");
});
