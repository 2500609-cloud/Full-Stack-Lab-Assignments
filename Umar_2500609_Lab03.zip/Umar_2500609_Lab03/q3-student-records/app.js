
const students = [
    {
        name: "Rehmeen",
        rollNo: "ADSCS-111-A",
        marks: 88
    },
    {
        name: "Maryam",
        rollNo: "ADSCS-111-A",
        marks: 74
    },
    {
        name: "Sidra",
        rollNo: "ADSCS-111-A",
        marks: 65
    },
    {
        name: "Saad",
        rollNo: "ADSCS-111-A",
        marks: 92
    },
    {
        name: "Umer",
        rollNo: "ADSCS-111-A",
        marks: 47
    }
];

const tableBody = document.getElementById("studentTableBody");
const summary = document.getElementById("summary");
const sortButton = document.getElementById("sortButton");


function getGrade(marks) {
    let grade;

    if (marks >= 85) {
        grade = "A";
    } else if (marks >= 70) {
        grade = "B";
    } else if (marks >= 50) {
        grade = "C";
    } else {
        grade = "F";
    }

    return grade;
}


function displayStudents() {
    tableBody.innerHTML = "";

    for (const student of students) {
        const row = document.createElement("tr");

        const nameCell = document.createElement("td");
        nameCell.textContent = student.name;

        const rollNoCell = document.createElement("td");
        rollNoCell.textContent = student.rollNo;

        const marksCell = document.createElement("td");
        marksCell.textContent = student.marks;

        const gradeCell = document.createElement("td");
        gradeCell.textContent = getGrade(student.marks);

        row.appendChild(nameCell);
        row.appendChild(rollNoCell);
        row.appendChild(marksCell);
        row.appendChild(gradeCell);

        tableBody.appendChild(row);
    }
}


function displaySummary() {
    let totalMarks = 0;
    let topStudent = students[0];

    for (const student of students) {
        totalMarks += student.marks;

        if (student.marks > topStudent.marks) {
            topStudent = student;
        }
    }

    const average = totalMarks / students.length;

    summary.innerHTML = `
        <strong>Class Average:</strong> ${average.toFixed(1)}<br>
        <strong>Top Scorer:</strong> ${topStudent.name}
    `;
}
function sortStudents() {
    students.sort((firstStudent, secondStudent) => {
        return secondStudent.marks - firstStudent.marks;
    });

    displayStudents();
    displaySummary();
}

sortButton.addEventListener("click", sortStudents);

displayStudents();
displaySummary();
