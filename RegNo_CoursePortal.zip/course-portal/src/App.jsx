// Name: YOUR NAME | Reg No: YOUR_REGNO
// App: chooses which page to show using state (no router).
import { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import LoginPage from './pages/LoginPage';
import CoursesPage from './pages/CoursesPage';
import MyCoursesPage from './pages/MyCoursesPage';
import ManagePage from './pages/ManagePage';

export default function App() {
  const { user, role } = useAuth();
  const [page, setPage] = useState('courses');

  // After login/logout go back to the courses page
  useEffect(() => {
    setPage('courses');
  }, [user]);

  // Role check: a student cannot open 'manage' and an admin cannot open 'my'
  let content;
  if (!user) content = <LoginPage />;
  else if (page === 'my' && role === 'student') content = <MyCoursesPage />;
  else if (page === 'manage' && role === 'admin') content = <ManagePage />;
  else content = <CoursesPage />;

  return (
    <>
      <Navbar page={page} onNavigate={setPage} />
      <main className="container">{content}</main>
    </>
  );
}
