// Name: YOUR NAME | Reg No: YOUR_REGNO
// AuthContext: provides { user, role, login, logout } to the whole app.
import { createContext, useContext, useCallback, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';

// No backend, so users live inside the code (see README for the list)
const USERS = [
  { username: 'admin', password: 'admin123', role: 'admin', name: 'Administrator' },
  { username: 'ali', password: 'ali123', role: 'student', name: 'Ali Raza' },
  { username: 'sara', password: 'sara123', role: 'student', name: 'Sara Khan' },
];

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // The logged-in user is kept in localStorage so a refresh does not log out
  const [user, setUser] = useLocalStorage('cp-user', null);

  // Returns { ok: true } or { ok: false, message } for the login page
  const login = useCallback(
    (username, password) => {
      const found = USERS.find(
        (u) => u.username === username.trim() && u.password === password
      );
      if (!found) return { ok: false, message: 'Wrong username or password.' };
      // Never store the password in state/localStorage
      setUser({ username: found.username, role: found.role, name: found.name });
      return { ok: true };
    },
    [setUser]
  );

  const logout = useCallback(() => setUser(null), [setUser]);

  const value = useMemo(
    () => ({ user, role: user ? user.role : null, login, logout }),
    [user, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
