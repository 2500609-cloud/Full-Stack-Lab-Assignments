// Name: YOUR NAME | Reg No: YOUR_REGNO
// CourseContext: courses + enrolments, managed with useReducer.
//  - base courses come from public/courses.json (via useFetch)
//  - admin changes (added / deleted courses) and student enrolments are
//    saved in localStorage (via useLocalStorage)
import {
  createContext,
  useContext,
  useReducer,
  useEffect,
  useMemo,
  useCallback,
} from 'react';
import useFetch from '../hooks/useFetch';
import useLocalStorage from '../hooks/useLocalStorage';

export const MAX_CREDITS = 18;

const CourseContext = createContext(null);

// ---------- Reducer ----------
// State shape:
//  enrolments: { [username]: [courseId, ...] }
//  added:      courses created by the admin
//  deletedIds: ids of courses removed by the admin
// Rule: never mutate state (no push / splice). Always return new objects.
const initialState = { enrolments: {}, added: [], deletedIds: [] };

function reducer(state, action) {
  switch (action.type) {
    case 'ENROL': {
      const current = state.enrolments[action.username] || [];
      if (current.includes(action.courseId)) return state; // no duplicates
      return {
        ...state,
        enrolments: {
          ...state.enrolments,
          [action.username]: [...current, action.courseId],
        },
      };
    }
    case 'DROP': {
      const current = state.enrolments[action.username] || [];
      return {
        ...state,
        enrolments: {
          ...state.enrolments,
          [action.username]: current.filter((id) => id !== action.courseId),
        },
      };
    }
    case 'ADD_COURSE':
      return { ...state, added: [...state.added, action.course] };
    case 'DELETE_COURSE':
      return {
        ...state,
        // an added course is removed from the list, a JSON course is hidden
        added: state.added.filter((c) => c.id !== action.courseId),
        deletedIds: [...state.deletedIds, action.courseId],
      };
    default:
      return state;
  }
}

export function CourseProvider({ children }) {
  const { data, loading, error } = useFetch('/courses.json');
  const [saved, setSaved] = useLocalStorage('cp-state', initialState);
  const [state, dispatch] = useReducer(reducer, saved);

  // Keep localStorage in sync with the reducer state
  useEffect(() => setSaved(state), [state, setSaved]);

  // Final course list = (json + added) - deleted
  const courses = useMemo(() => {
    const all = [...(data || []), ...state.added];
    return all.filter((c) => !state.deletedIds.includes(c.id));
  }, [data, state.added, state.deletedIds]);

  const enrolledIds = useCallback(
    (username) => state.enrolments[username] || [],
    [state.enrolments]
  );

  // Each action returns { ok, message } so the UI can show a clear message
  const enrol = useCallback(
    (username, courseId) => {
      const ids = (state.enrolments[username] || []).filter((id) =>
        courses.some((c) => c.id === id)
      );
      const course = courses.find((c) => c.id === courseId);
      if (!course) return { ok: false, message: 'Course not found.' };
      if (ids.includes(courseId))
        return { ok: false, message: `You are already enrolled in ${course.code}.` };

      const total = ids.reduce(
        (sum, id) => sum + courses.find((c) => c.id === id).credits,
        0
      );
      if (total + course.credits > MAX_CREDITS)
        return {
          ok: false,
          message: `Cannot enrol in ${course.code}: this would make ${
            total + course.credits
          } credits (limit is ${MAX_CREDITS}).`,
        };

      dispatch({ type: 'ENROL', username, courseId });
      return { ok: true, message: `Enrolled in ${course.code} - ${course.title}.` };
    },
    [state.enrolments, courses]
  );

  const drop = useCallback((username, courseId) => {
    dispatch({ type: 'DROP', username, courseId });
  }, []);

  const addCourse = useCallback(
    (fields) => {
      // New id = highest existing id (even deleted ones) + 1, so ids never repeat
      const maxId = Math.max(
        0,
        ...(data || []).map((c) => c.id),
        ...state.added.map((c) => c.id)
      );
      const course = { ...fields, id: maxId + 1 };
      dispatch({ type: 'ADD_COURSE', course });
    },
    [data, state.added]
  );

  const deleteCourse = useCallback((courseId) => {
    dispatch({ type: 'DELETE_COURSE', courseId });
  }, []);

  const value = {
    courses,
    loading,
    error,
    enrolledIds,
    enrol,
    drop,
    addCourse,
    deleteCourse,
  };

  return <CourseContext.Provider value={value}>{children}</CourseContext.Provider>;
}

export function useCourses() {
  const ctx = useContext(CourseContext);
  if (!ctx) throw new Error('useCourses must be used inside <CourseProvider>');
  return ctx;
}
