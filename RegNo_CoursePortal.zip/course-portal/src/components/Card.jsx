// Name: YOUR NAME | Reg No: YOUR_REGNO
// Reusable Card: wraps whatever is placed between <Card> ... </Card> (children).
export default function Card({ title, children, className = '' }) {
  return (
    <section className={`card ${className}`}>
      {title && <h2 className="card-title">{title}</h2>}
      {children}
    </section>
  );
}
