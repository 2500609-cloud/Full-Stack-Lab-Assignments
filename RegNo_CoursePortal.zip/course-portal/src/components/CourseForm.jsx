// Name: YOUR NAME | Reg No: YOUR_REGNO
// CourseForm: admin form to add a course, with validation.
//  - title: not empty
//  - code: pattern like CS-301 (2-3 capital letters, dash, 3 digits)
//  - credits: whole number from 1 to 4
//  - instructor name is also required (a course needs someone to teach it)
import { useState, useRef, useEffect } from 'react';
import Card from './Card';
import Button from './Button';

const CODE_PATTERN = /^[A-Z]{2,3}-\d{3}$/;
const emptyForm = { title: '', code: '', credits: '', instructorName: '', instructorEmail: '' };

// Returns an object with one message per wrong field ({} means valid)
function validate(f, existingCodes) {
  const errors = {};
  if (!f.title.trim()) errors.title = 'Title cannot be empty.';
  if (!CODE_PATTERN.test(f.code.trim()))
    errors.code = 'Code must look like CS-301 (capital letters, dash, 3 digits).';
  else if (existingCodes.includes(f.code.trim()))
    errors.code = 'A course with this code already exists.';
  const credits = Number(f.credits);
  if (f.credits === '' || !Number.isInteger(credits) || credits < 1 || credits > 4)
    errors.credits = 'Credits must be a whole number from 1 to 4.';
  if (!f.instructorName.trim()) errors.instructorName = 'Instructor name is required.';
  if (f.instructorEmail && !/^\S+@\S+\.\S+$/.test(f.instructorEmail.trim()))
    errors.instructorEmail = 'Enter a valid email or leave it empty.';
  return errors;
}

export default function CourseForm({ onAdd, existingCodes = [] }) {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState('');
  const firstInput = useRef(null); // useRef: focus the first input

  useEffect(() => {
    firstInput.current.focus();
  }, []);

  // One handler for all inputs: uses the input's name attribute
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setSuccess('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const found = validate(form, existingCodes);
    setErrors(found);
    if (Object.keys(found).length > 0) return; // stop: show the messages

    onAdd({
      title: form.title.trim(),
      code: form.code.trim(),
      credits: Number(form.credits),
      instructor: {
        name: form.instructorName.trim(),
        email: form.instructorEmail.trim(),
      },
    });
    setSuccess(`Course ${form.code.trim()} added.`);
    setForm(emptyForm);
    firstInput.current.focus();
  };

  return (
    <Card title="Add a course">
      <form onSubmit={handleSubmit} noValidate className="form">
        <label>
          Title
          <input ref={firstInput} name="title" value={form.title} onChange={handleChange} />
          {errors.title && <span className="error">{errors.title}</span>}
        </label>
        <label>
          Code (e.g. CS-301)
          <input name="code" value={form.code} onChange={handleChange} />
          {errors.code && <span className="error">{errors.code}</span>}
        </label>
        <label>
          Credits (1-4)
          <input name="credits" type="number" value={form.credits} onChange={handleChange} />
          {errors.credits && <span className="error">{errors.credits}</span>}
        </label>
        <label>
          Instructor name
          <input name="instructorName" value={form.instructorName} onChange={handleChange} />
          {errors.instructorName && <span className="error">{errors.instructorName}</span>}
        </label>
        <label>
          Instructor email (optional)
          <input name="instructorEmail" value={form.instructorEmail} onChange={handleChange} />
          {errors.instructorEmail && <span className="error">{errors.instructorEmail}</span>}
        </label>
        <Button type="submit">Add course</Button>
        {success && <p className="success">{success}</p>}
      </form>
    </Card>
  );
}
