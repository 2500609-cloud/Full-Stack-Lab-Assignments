// Name: YOUR NAME | Reg No: YOUR_REGNO
// Navbar: shows links that depend on the role, the theme toggle and logout.
// There is no router, so the current page lives in App's state and is
// passed here as props (page, onNavigate).
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import Button from './Button';

export default function Navbar({ page, onNavigate }) {
  const { user, role, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const links = [{ id: 'courses', label: 'Courses' }];
  if (role === 'student') links.push({ id: 'my', label: 'My Courses' });
  if (role === 'admin') links.push({ id: 'manage', label: 'Manage' });

  return (
    <header className="navbar">
      <strong className="brand">Course Portal</strong>
      {user && (
        <nav className="nav-links">
          {links.map((l) => (
            <button
              key={l.id}
              className={`nav-link ${page === l.id ? 'active' : ''}`}
              onClick={() => onNavigate(l.id)}
            >
              {l.label}
            </button>
          ))}
        </nav>
      )}
      <div className="nav-right">
        <Button variant="ghost" onClick={toggleTheme}>
          {theme === 'light' ? 'Dark' : 'Light'} mode
        </Button>
        {user && (
          <>
            <span className="muted">{user.name} ({role})</span>
            <Button variant="ghost" onClick={logout}>Logout</Button>
          </>
        )}
      </div>
    </header>
  );
}
