// Name: YOUR NAME | Reg No: YOUR_REGNO
// CourseCard: shows one course. Wrapped in memo() so it only re-renders when
// its own props change (callbacks are passed using useCallback in the pages).
//  props: course, onEnrol, onDrop, onDelete (callback props),
//         enrolled (bool), mode ('browse' | 'enrolled' | 'manage')
import { memo } from 'react';
import Card from './Card';
import Button from './Button';

function CourseCard({ course, mode = 'browse', enrolled = false, onEnrol, onDrop, onDelete }) {
  return (
    <Card className="course-card">
      <div className="course-head">
        <span className="badge">{course.code}</span>
        <span className="credits">{course.credits} credit{course.credits > 1 ? 's' : ''}</span>
      </div>
      <h3>{course.title}</h3>
      {/* child properties: course.instructor.name / .email */}
      <p className="muted">
        {course.instructor.name}
        <br />
        <a href={`mailto:${course.instructor.email}`}>{course.instructor.email}</a>
      </p>

      <div className="card-actions">
        {mode === 'browse' && onEnrol && (
          enrolled ? (
            <span className="tag-ok">Enrolled</span>
          ) : (
            <Button onClick={() => onEnrol(course.id)}>Enrol</Button>
          )
        )}
        {mode === 'enrolled' && (
          <Button variant="danger" onClick={() => onDrop(course.id)}>Drop</Button>
        )}
        {mode === 'manage' && (
          <Button variant="danger" onClick={() => onDelete(course.id)}>Delete</Button>
        )}
      </div>
    </Card>
  );
}

export default memo(CourseCard);
