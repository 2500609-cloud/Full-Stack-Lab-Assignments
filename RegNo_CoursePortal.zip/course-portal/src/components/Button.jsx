// Name: YOUR NAME | Reg No: YOUR_REGNO
// Reusable Button. variant: 'primary' | 'danger' | 'ghost'
export default function Button({
  children,
  onClick,
  variant = 'primary',
  type = 'button',
  disabled = false,
}) {
  return (
    <button
      type={type}
      className={`btn btn-${variant}`}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
