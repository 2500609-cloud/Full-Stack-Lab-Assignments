// Name: YOUR NAME | Reg No: YOUR_REGNO
// MyCoursesPage (student): enrolled courses, total credits and Drop button.
import { useMemo, useCallback, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCourses, MAX_CREDITS } from '../context/CourseContext';
import CourseCard from '../components/CourseCard';

export default function MyCoursesPage() {
  const { user } = useAuth();
  const { courses, loading, error, enrolledIds, drop } = useCourses();

  useEffect(() => {
    document.title = 'My Courses | Course Portal';
  }, []);

  const myIds = enrolledIds(user.username);

  // The student's courses; useMemo avoids recalculating on every render
  const myCourses = useMemo(
    () => courses.filter((c) => myIds.includes(c.id)),
    [courses, myIds]
  );
  const totalCredits = useMemo(
    () => myCourses.reduce((sum, c) => sum + c.credits, 0),
    [myCourses]
  );

  const handleDrop = useCallback((id) => drop(user.username, id), [drop, user.username]);

  if (loading) return <p className="status">Loading courses...</p>;
  if (error) return <p className="status error">Error: {error}</p>;

  return (
    <div>
      <h1>My Courses</h1>
      <p className="summary">
        Total credits: <strong>{totalCredits}</strong> / {MAX_CREDITS}
      </p>
      {myCourses.length === 0 ? (
        <p className="status">You have not enrolled in any course yet.</p>
      ) : (
        <div className="grid">
          {myCourses.map((c) => (
            <CourseCard key={c.id} course={c} mode="enrolled" onDrop={handleDrop} />
          ))}
        </div>
      )}
    </div>
  );
}
