// Name: YOUR NAME | Reg No: YOUR_REGNO
// ManagePage (admin): add a course (form) and delete courses.
import { useCallback, useEffect } from 'react';
import { useCourses } from '../context/CourseContext';
import CourseForm from '../components/CourseForm';
import CourseCard from '../components/CourseCard';

export default function ManagePage() {
  const { courses, loading, error, addCourse, deleteCourse } = useCourses();

  useEffect(() => {
    document.title = 'Manage | Course Portal';
  }, []);

  const handleDelete = useCallback((id) => deleteCourse(id), [deleteCourse]);

  if (loading) return <p className="status">Loading courses...</p>;
  if (error) return <p className="status error">Error: {error}</p>;

  return (
    <div>
      <h1>Manage Courses</h1>
      <CourseForm onAdd={addCourse} existingCodes={courses.map((c) => c.code)} />
      <h2>All courses ({courses.length})</h2>
      <div className="grid">
        {courses.map((c) => (
          <CourseCard key={c.id} course={c} mode="manage" onDelete={handleDelete} />
        ))}
      </div>
    </div>
  );
}
