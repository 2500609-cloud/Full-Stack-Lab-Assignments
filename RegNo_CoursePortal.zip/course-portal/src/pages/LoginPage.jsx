// Name: YOUR NAME | Reg No: YOUR_REGNO
// LoginPage: username + password. A wrong login shows a red message.
import { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import Card from '../components/Card';
import Button from '../components/Button';

export default function LoginPage() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const usernameRef = useRef(null);

  useEffect(() => {
    document.title = 'Login | Course Portal';
    usernameRef.current.focus(); // focus the first input
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = login(username, password);
    if (!result.ok) setMessage(result.message); // red message below the form
  };

  return (
    <div className="center">
      <Card title="Login" className="login-card">
        <form onSubmit={handleSubmit} className="form">
          <label>
            Username
            <input
              ref={usernameRef}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </label>
          <Button type="submit">Login</Button>
          {message && <p className="error" role="alert">{message}</p>}
        </form>
      </Card>
    </div>
  );
}
