// Name: YOUR NAME | Reg No: YOUR_REGNO
// CoursesPage: all courses with search box, credits filter and Enrol button.
import { useState, useMemo, useCallback, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCourses } from '../context/CourseContext';
import useDebounce from '../hooks/useDebounce';
import CourseCard from '../components/CourseCard';

export default function CoursesPage() {
  const { user, role } = useAuth();
  const { courses, loading, error, enrolledIds, enrol } = useCourses();
  const [search, setSearch] = useState('');
  const [credits, setCredits] = useState('all');
  const [notice, setNotice] = useState(null); // { ok, message }
  const debouncedSearch = useDebounce(search, 250);

  useEffect(() => {
    document.title = 'Courses | Course Portal';
  }, []);

  // useMemo: filter again only when the list, search or credits change
  const filtered = useMemo(() => {
    const q = debouncedSearch.trim().toLowerCase();
    return courses.filter((c) => {
      const matchesText =
        c.title.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q) ||
        c.instructor.name.toLowerCase().includes(q);
      const matchesCredits = credits === 'all' || c.credits === Number(credits);
      return matchesText && matchesCredits;
    });
  }, [courses, debouncedSearch, credits]);

  const myIds = role === 'student' ? enrolledIds(user.username) : [];

  // useCallback keeps the same function so memo(CourseCard) can skip renders
  const handleEnrol = useCallback(
    (courseId) => setNotice(enrol(user.username, courseId)),
    [enrol, user.username]
  );

  if (loading) return <p className="status">Loading courses...</p>;
  if (error) return <p className="status error">Error: {error}</p>;

  return (
    <div>
      <h1>Courses</h1>
      <div className="toolbar">
        <input
          type="search"
          placeholder="Search by title, code or instructor"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select value={credits} onChange={(e) => setCredits(e.target.value)}>
          <option value="all">All credits</option>
          {[1, 2, 3, 4].map((n) => (
            <option key={n} value={n}>{n} credit{n > 1 ? 's' : ''}</option>
          ))}
        </select>
      </div>

      {notice && (
        <p className={notice.ok ? 'success' : 'error'} role="alert">{notice.message}</p>
      )}

      {filtered.length === 0 ? (
        <p className="status">No courses match your search.</p>
      ) : (
        <div className="grid">
          {filtered.map((c) => (
            <CourseCard
              key={c.id}
              course={c}
              mode="browse"
              enrolled={myIds.includes(c.id)}
              onEnrol={role === 'student' ? handleEnrol : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}
