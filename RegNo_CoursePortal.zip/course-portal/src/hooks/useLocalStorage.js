// Name: YOUR NAME | Reg No: YOUR_REGNO
// Custom hook #2: useLocalStorage
// Works like useState, but the value is also saved in the browser's localStorage.
import { useState, useEffect } from 'react';

export default function useLocalStorage(key, initialValue) {
  // Lazy initial state: read from localStorage only once, on first render
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key);
      return saved !== null ? JSON.parse(saved) : initialValue;
    } catch {
      return initialValue; // corrupted JSON or storage blocked
    }
  });

  // Save every time the value changes
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage full or blocked - ignore */
    }
  }, [key, value]);

  return [value, setValue];
}
