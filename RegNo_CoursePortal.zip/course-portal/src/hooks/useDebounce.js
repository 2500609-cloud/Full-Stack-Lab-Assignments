// Name: YOUR NAME | Reg No: YOUR_REGNO
// Custom hook #3 (bonus): useDebounce
// Returns the value only after the user stops changing it for `delay` ms.
// Used by the search box so the list is not re-filtered on every key press.
import { useState, useEffect } from 'react';

export default function useDebounce(value, delay = 250) {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer); // restart the timer on each change
  }, [value, delay]);

  return debounced;
}
