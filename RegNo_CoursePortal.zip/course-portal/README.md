<!-- Name: YOUR NAME | Reg No: YOUR_REGNO -->
# Student Course Portal

Full Stack Web Development Lab (CS-301L), Air University. React + Vite, no backend.
Courses are loaded with `fetch` from `public/courses.json`; everything the user changes is saved in `localStorage`.

## How to run

```bash
npm install
npm run dev
```

Then open the address shown in the terminal (usually http://localhost:5173).

## Login details

| Role    | Username | Password   |
|---------|----------|------------|
| Admin   | admin    | admin123   |
| Student | ali      | ali123     |
| Student | sara     | sara123    |

## Features

- **Login**: wrong username/password shows a red message.
- **Courses** (all users): search box (title, code, instructor), credits filter, Enrol button (students only).
- **My Courses** (student): enrolled courses, total credits, Drop button.
- **Manage** (admin): add-course form with validation, Delete button on every course.
- **Rules**: no double enrolment; maximum 18 credits per student (clear message shown).
- **Bonus**: dark/light theme (ThemeContext) and a third custom hook (`useDebounce`).

## Lab topics used

| Topic | Where |
|-------|-------|
| `fetch` + Loading/Error | `hooks/useFetch.js`, used in `CourseContext` |
| Custom hooks | `useFetch`, `useLocalStorage`, `useDebounce` (bonus) |
| Context API | `AuthContext`, `CourseContext`, `ThemeContext` (bonus) |
| `useReducer` | `CourseContext` (ENROL, DROP, ADD_COURSE, DELETE_COURSE) |
| `useMemo` | filtered list (`CoursesPage`), total credits (`MyCoursesPage`) |
| `useCallback` + `memo` | `CourseCard` and the handlers passed to it |
| `useRef` | focus first input in `CourseForm` and `LoginPage` |
| `useEffect` | `document.title` on every page |
| Props / callback props / child props | `CourseCard` (`course.instructor.name`), `Card` children |

## Folder structure

```
course-portal/
  public/courses.json
  src/
    components/  Navbar, CourseCard, Button, Card, CourseForm
    pages/       LoginPage, CoursesPage, MyCoursesPage, ManagePage
    context/     AuthContext, CourseContext, ThemeContext
    hooks/       useFetch, useLocalStorage, useDebounce
    App.jsx  main.jsx  index.css
  screenshots/
```

## Screenshots

See the `screenshots/` folder: login error, courses list, My Courses, admin add-course error.

To reset all saved data, clear this site's localStorage in the browser dev tools.
