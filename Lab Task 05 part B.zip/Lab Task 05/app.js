
const todoForm = document.getElementById("todoForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const errorMessage = document.getElementById("errorMessage");
const totalTasks = document.getElementById("totalTasks");
const remainingTasks = document.getElementById("remainingTasks");
const clearCompleted = document.getElementById("clearCompleted");
const filterButtons = document.querySelectorAll(".filter");

let tasks = [];
let currentFilter = "all";
let editingId = null;

todoForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const taskText = taskInput.value.trim();

    if (taskText === "") {
        errorMessage.textContent = "Please enter a task.";
        return;
    }

    const duplicate = tasks.some(function (task) {
        return task.text.toLowerCase() === taskText.toLowerCase();
    });

    if (duplicate) {
        errorMessage.textContent = "This task already exists.";
        return;
    }

    errorMessage.textContent = "";

    tasks.push({
        id: Date.now(),
        text: taskText,
        completed: false
    });

    taskInput.value = "";

    renderTasks();
});

function renderTasks() {
    taskList.innerHTML = "";

    let filteredTasks = tasks;

    if (currentFilter === "active") {
        filteredTasks = tasks.filter(function (task) {
            return !task.completed;
        });
    }

    if (currentFilter === "completed") {
        filteredTasks = tasks.filter(function (task) {
            return task.completed;
        });
    }

    filteredTasks.forEach(function (task) {
        const li = document.createElement("li");

        li.classList.add("task");
        li.dataset.id = task.id;

        if (task.completed) {
            li.classList.add("completed");
        }

        if (editingId === task.id) {
            li.innerHTML = `
                <input
                    type="text"
                    class="edit-input"
                    value="${task.text}"
                >
            `;

            taskList.appendChild(li);

            const editInput = li.querySelector(".edit-input");

            editInput.focus();

            editInput.addEventListener("keydown", function (event) {
                if (event.key === "Enter") {
                    saveEdit(task.id, editInput.value);
                }

                if (event.key === "Escape") {
                    editingId = null;
                    renderTasks();
                }
            });

            return;
        }

        li.innerHTML = `
            <input
                type="checkbox"
                class="complete-checkbox"
                ${task.completed ? "checked" : ""}
            >

            <span class="task-text">${task.text}</span>

            <button class="delete-btn">
                Delete
            </button>
        `;

        taskList.appendChild(li);
    });

    updateCounter();
}

function saveEdit(id, newText) {
    const updatedText = newText.trim();

    if (updatedText === "") {
        errorMessage.textContent = "Task cannot be empty.";
        return;
    }

    const duplicate = tasks.some(function (task) {
        return (
            task.id !== id &&
            task.text.toLowerCase() === updatedText.toLowerCase()
        );
    });

    if (duplicate) {
        errorMessage.textContent = "This task already exists.";
        return;
    }

    const task = tasks.find(function (task) {
        return task.id === id;
    });

    if (task) {
        task.text = updatedText;
    }

    errorMessage.textContent = "";
    editingId = null;

    renderTasks();
}

taskList.addEventListener("click", function (event) {
    const taskItem = event.target.closest(".task");

    if (!taskItem) {
        return;
    }

    const taskId = Number(taskItem.dataset.id);

    if (event.target.classList.contains("delete-btn")) {
        tasks = tasks.filter(function (task) {
            return task.id !== taskId;
        });

        if (editingId === taskId) {
            editingId = null;
        }

        renderTasks();
        return;
    }

    if (event.target.classList.contains("task-text")) {
        editingId = taskId;
        errorMessage.textContent = "";
        renderTasks();
    }
});

taskList.addEventListener("change", function (event) {
    if (!event.target.classList.contains("complete-checkbox")) {
        return;
    }

    const taskItem = event.target.closest(".task");
    const taskId = Number(taskItem.dataset.id);

    const task = tasks.find(function (task) {
        return task.id === taskId;
    });

    if (task) {
        task.completed = event.target.checked;
    }

    renderTasks();
});

taskList.addEventListener("dblclick", function (event) {
    if (!event.target.classList.contains("task-text")) {
        return;
    }

    const taskItem = event.target.closest(".task");
    const taskId = Number(taskItem.dataset.id);

    editingId = taskId;
    errorMessage.textContent = "";

    renderTasks();
});

function updateCounter() {
    const total = tasks.length;

    const remaining = tasks.filter(function (task) {
        return !task.completed;
    }).length;

    totalTasks.textContent = total;
    remainingTasks.textContent = remaining;
}

filterButtons.forEach(function (button) {
    button.addEventListener("click", function () {
        currentFilter = button.dataset.filter;

        filterButtons.forEach(function (btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        renderTasks();
    });
});

clearCompleted.addEventListener("click", function () {
    tasks = tasks.filter(function (task) {
        return !task.completed;
    });

    renderTasks();
});

taskInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        todoForm.requestSubmit();
    }
});

renderTasks();
